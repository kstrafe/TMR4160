#! /bin/bash

rm *.image *.png velocities out.mov 2>/dev/null
