#! /bin/bash

rm *.image *.png pressures out.mov 2>/dev/null
