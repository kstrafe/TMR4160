#! /bin/bash

rm *.image *.png streams out.mov 2>/dev/null
